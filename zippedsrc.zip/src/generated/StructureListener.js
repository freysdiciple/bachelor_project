// Generated from Structure.g4 by ANTLR 4.12.0
// jshint ignore: start
import antlr4 from 'antlr4';

// This class defines a complete listener for a parse tree produced by StructureParser.
export default class StructureListener extends antlr4.tree.ParseTreeListener {

	// Enter a parse tree produced by StructureParser#struct.
	enterStruct(ctx) {
	}

	// Exit a parse tree produced by StructureParser#struct.
	exitStruct(ctx) {
	}


	// Enter a parse tree produced by StructureParser#def.
	enterDef(ctx) {
	}

	// Exit a parse tree produced by StructureParser#def.
	exitDef(ctx) {
	}


	// Enter a parse tree produced by StructureParser#node.
	enterNode(ctx) {
	}

	// Exit a parse tree produced by StructureParser#node.
	exitNode(ctx) {
	}


	// Enter a parse tree produced by StructureParser#gate.
	enterGate(ctx) {
	}

	// Exit a parse tree produced by StructureParser#gate.
	exitGate(ctx) {
	}


	// Enter a parse tree produced by StructureParser#relation.
	enterRelation(ctx) {
	}

	// Exit a parse tree produced by StructureParser#relation.
	exitRelation(ctx) {
	}


	// Enter a parse tree produced by StructureParser#give.
	enterGive(ctx) {
	}

	// Exit a parse tree produced by StructureParser#give.
	exitGive(ctx) {
	}


	// Enter a parse tree produced by StructureParser#flow.
	enterFlow(ctx) {
	}

	// Exit a parse tree produced by StructureParser#flow.
	exitFlow(ctx) {
	}


	// Enter a parse tree produced by StructureParser#connections.
	enterConnections(ctx) {
	}

	// Exit a parse tree produced by StructureParser#connections.
	exitConnections(ctx) {
	}


	// Enter a parse tree produced by StructureParser#connection.
	enterConnection(ctx) {
	}

	// Exit a parse tree produced by StructureParser#connection.
	exitConnection(ctx) {
	}


	// Enter a parse tree produced by StructureParser#dict.
	enterDict(ctx) {
	}

	// Exit a parse tree produced by StructureParser#dict.
	exitDict(ctx) {
	}


	// Enter a parse tree produced by StructureParser#keyValuePairs.
	enterKeyValuePairs(ctx) {
	}

	// Exit a parse tree produced by StructureParser#keyValuePairs.
	exitKeyValuePairs(ctx) {
	}


	// Enter a parse tree produced by StructureParser#attribute.
	enterAttribute(ctx) {
	}

	// Exit a parse tree produced by StructureParser#attribute.
	exitAttribute(ctx) {
	}


	// Enter a parse tree produced by StructureParser#attRef.
	enterAttRef(ctx) {
	}

	// Exit a parse tree produced by StructureParser#attRef.
	exitAttRef(ctx) {
	}


	// Enter a parse tree produced by StructureParser#array.
	enterArray(ctx) {
	}

	// Exit a parse tree produced by StructureParser#array.
	exitArray(ctx) {
	}


	// Enter a parse tree produced by StructureParser#type.
	enterType(ctx) {
	}

	// Exit a parse tree produced by StructureParser#type.
	exitType(ctx) {
	}


	// Enter a parse tree produced by StructureParser#flat.
	enterFlat(ctx) {
	}

	// Exit a parse tree produced by StructureParser#flat.
	exitFlat(ctx) {
	}



}
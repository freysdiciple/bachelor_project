
// Generated from Structure.g4 by ANTLR 4.12.0
// jshint ignore: start
import antlr4 from 'antlr4';
import { Structure } from "../parsing/GraphObjects";
import { Node, Gate } from "../parsing/Vertex";
import { Relation, Flow, Give } from '../parsing/Edge';
import { Attribute, Connection, FlatType, ArrayType, DictType } from '../parsing/Attribute';

// This class defines a complete generic visitor for a parse tree produced by StructureParser.

export default class StructureVisitor extends antlr4.tree.ParseTreeVisitor {

	// Visit a parse tree produced by StructureParser#struct.
	visitStruct(ctx) {
		const structure = new Structure();
		structure.setElements(this.visitChildren(ctx));
	  	return structure;
	}


	// Visit a parse tree produced by StructureParser#def.
	visitDef(ctx) {
		return this.visitChildren(ctx)[0];
	}


	// Visit a parse tree produced by StructureParser#node.
	visitNode(ctx) {
		//Create node object
		const node = new Node(
			ctx.getChild(0).getText(), //Type
			ctx.getChild(1).getText()  //Name
		);

		//Add attributes
		node.attributes = this.visitDict(ctx.getChild(2));

	    return node;
	}


	// Visit a parse tree produced by StructureParser#gate.
	visitGate(ctx) {
	  return new Gate(ctx.getChild(0).getText(), ctx.getChild(1).getText());
	}


	// Visit a parse tree produced by StructureParser#relation.
	visitRelation(ctx) {
	  	return new Relation(
			ctx.getChild(0).getText(),
			ctx.getChild(1).getText(),
			ctx.getChild(4).getText(),
			ctx.getChild(2).getText(),
			ctx.getChild(5).getText()
		);
	}


	// Visit a parse tree produced by StructureParser#give.
	visitGive(ctx) {
	  	return new Give(
			ctx.getChild(0).getText(),
			ctx.getChild(1).getText(),
			ctx.getChild(3).getText(),
	  	);
	}


	// Visit a parse tree produced by StructureParser#flow.
	visitFlow(ctx) {
		let flow = new Flow(
			ctx.getChild(0).getText(),
			ctx.getChild(1).getText(),
			ctx.getChild(2).getText(),
			ctx.getChild(4).getText()
		);

		flow.connections = this.visitConnections(ctx.getChild(5));

		return flow;
	}


	// Visit a parse tree produced by StructureParser#connections.
	visitConnections(ctx) {
		let length = ctx.children.length;
		if(length < 3) return [];
		if(ctx.getChild(1).getText() === "*") return [new Flow(null,null,true)]

		let result = [];
		for(let i=1; i<length; i+=2){
			result.push(this.visitConnection(ctx.getChild(i)));
		}
		return result;
	}


	// Visit a parse tree produced by StructureParser#connection.
	visitConnection(ctx) {
	  return new Connection(
		this.visitAttRef(ctx.getChild(0)),
		this.visitAttRef(ctx.getChild(2)),
		false
	  );
	}


	// Visit a parse tree produced by StructureParser#dict.
	visitDict(ctx) {
		if(ctx.children.length < 3) return new DictType([]);
		else return new DictType(this.visitKeyValuePairs(ctx.getChild(1)));
	}


	// Visit a parse tree produced by StructureParser#keyValuePairs.
	visitKeyValuePairs(ctx) {
		let length = ctx.children.length;
		let result = [];
		for(let i=0; i<length; i+=2){
			result.push(this.visitAttribute(ctx.getChild(i)));
		}
	  	return result;
	}


	// Visit a parse tree produced by StructureParser#attribute.
	visitAttribute(ctx) {
		return new Attribute(this.visitType(ctx.getChild(2)), ctx.getChild(0).getText());
	}


	// Visit a parse tree produced by StructureParser#attRef.
	visitAttRef(ctx) {
		let length = ctx.children.length;
		let result = [];

		for(let i=0; i<length; i+=2){
			result.push(ctx.getChild(i).getText())
		}

	  	return result;
	}


	// Visit a parse tree produced by StructureParser#array.
	visitArray(ctx) {
	  return new ArrayType(this.visitType(ctx.getChild(0)));
	}


	// Visit a parse tree produced by StructureParser#type.
	visitType(ctx) {
	  return this.visitChildren(ctx)[0];
	}


	// Visit a parse tree produced by StructureParser#flat.
	visitFlat(ctx) {
	  return new FlatType(ctx.getChild(0).getText())
	}
}
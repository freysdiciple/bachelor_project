// Generated from Structure.g4 by ANTLR 4.12.0
// jshint ignore: start
import antlr4 from 'antlr4';
import StructureListener from './StructureListener.js';
import StructureVisitor from './StructureVisitor.js';

const serializedATN = [4,1,25,129,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,
4,2,5,7,5,2,6,7,6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,
2,13,7,13,2,14,7,14,2,15,7,15,1,0,5,0,34,8,0,10,0,12,0,37,9,0,1,0,1,0,1,
1,1,1,1,1,1,1,1,1,3,1,46,8,1,1,2,1,2,1,2,1,2,1,3,1,3,1,3,1,4,1,4,1,4,1,4,
1,4,1,4,1,4,1,5,1,5,1,5,1,5,1,5,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,7,1,7,1,7,
1,7,1,7,5,7,79,8,7,10,7,12,7,82,9,7,3,7,84,8,7,1,7,1,7,1,8,1,8,1,8,1,8,1,
9,1,9,3,9,94,8,9,1,9,1,9,1,10,1,10,1,10,5,10,101,8,10,10,10,12,10,104,9,
10,1,11,1,11,1,11,1,11,1,12,1,12,1,12,5,12,113,8,12,10,12,12,12,116,9,12,
1,13,1,13,1,13,1,13,1,14,1,14,1,14,3,14,125,8,14,1,15,1,15,1,15,0,0,16,0,
2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,0,3,1,0,7,8,1,0,9,10,1,0,1,6,125,
0,35,1,0,0,0,2,45,1,0,0,0,4,47,1,0,0,0,6,51,1,0,0,0,8,54,1,0,0,0,10,61,1,
0,0,0,12,66,1,0,0,0,14,73,1,0,0,0,16,87,1,0,0,0,18,91,1,0,0,0,20,97,1,0,
0,0,22,105,1,0,0,0,24,109,1,0,0,0,26,117,1,0,0,0,28,124,1,0,0,0,30,126,1,
0,0,0,32,34,3,2,1,0,33,32,1,0,0,0,34,37,1,0,0,0,35,33,1,0,0,0,35,36,1,0,
0,0,36,38,1,0,0,0,37,35,1,0,0,0,38,39,5,0,0,1,39,1,1,0,0,0,40,46,3,4,2,0,
41,46,3,6,3,0,42,46,3,8,4,0,43,46,3,12,6,0,44,46,3,10,5,0,45,40,1,0,0,0,
45,41,1,0,0,0,45,42,1,0,0,0,45,43,1,0,0,0,45,44,1,0,0,0,46,3,1,0,0,0,47,
48,7,0,0,0,48,49,5,24,0,0,49,50,3,18,9,0,50,5,1,0,0,0,51,52,7,1,0,0,52,53,
5,24,0,0,53,7,1,0,0,0,54,55,5,11,0,0,55,56,5,24,0,0,56,57,5,24,0,0,57,58,
5,14,0,0,58,59,5,23,0,0,59,60,5,24,0,0,60,9,1,0,0,0,61,62,5,13,0,0,62,63,
5,24,0,0,63,64,5,14,0,0,64,65,5,24,0,0,65,11,1,0,0,0,66,67,5,12,0,0,67,68,
5,24,0,0,68,69,5,24,0,0,69,70,5,14,0,0,70,71,5,24,0,0,71,72,3,14,7,0,72,
13,1,0,0,0,73,83,5,15,0,0,74,84,5,22,0,0,75,80,3,16,8,0,76,77,5,19,0,0,77,
79,3,16,8,0,78,76,1,0,0,0,79,82,1,0,0,0,80,78,1,0,0,0,80,81,1,0,0,0,81,84,
1,0,0,0,82,80,1,0,0,0,83,74,1,0,0,0,83,75,1,0,0,0,83,84,1,0,0,0,84,85,1,
0,0,0,85,86,5,16,0,0,86,15,1,0,0,0,87,88,3,24,12,0,88,89,5,14,0,0,89,90,
3,24,12,0,90,17,1,0,0,0,91,93,5,15,0,0,92,94,3,20,10,0,93,92,1,0,0,0,93,
94,1,0,0,0,94,95,1,0,0,0,95,96,5,16,0,0,96,19,1,0,0,0,97,102,3,22,11,0,98,
99,5,19,0,0,99,101,3,22,11,0,100,98,1,0,0,0,101,104,1,0,0,0,102,100,1,0,
0,0,102,103,1,0,0,0,103,21,1,0,0,0,104,102,1,0,0,0,105,106,5,24,0,0,106,
107,5,21,0,0,107,108,3,28,14,0,108,23,1,0,0,0,109,114,5,24,0,0,110,111,5,
20,0,0,111,113,5,24,0,0,112,110,1,0,0,0,113,116,1,0,0,0,114,112,1,0,0,0,
114,115,1,0,0,0,115,25,1,0,0,0,116,114,1,0,0,0,117,118,5,17,0,0,118,119,
3,28,14,0,119,120,5,18,0,0,120,27,1,0,0,0,121,125,3,30,15,0,122,125,3,26,
13,0,123,125,3,18,9,0,124,121,1,0,0,0,124,122,1,0,0,0,124,123,1,0,0,0,125,
29,1,0,0,0,126,127,7,2,0,0,127,31,1,0,0,0,8,35,45,80,83,93,102,114,124];


const atn = new antlr4.atn.ATNDeserializer().deserialize(serializedATN);

const decisionsToDFA = atn.decisionToState.map( (ds, index) => new antlr4.dfa.DFA(ds, index) );

const sharedContextCache = new antlr4.atn.PredictionContextCache();

export default class StructureParser extends antlr4.Parser {

    static grammarFileName = "Structure.g4";
    static literalNames = [ null, "'string'", "'reference'", "'integer'", 
                            "'float'", "'boolean'", "'datetime'", "'doc'", 
                            "'map'", "'funnel'", "'invert'", "'relation'", 
                            "'flow'", "'give'", "'->'", "'{'", "'}'", "'['", 
                            "']'", "','", "'.'", "':'", "'*'" ];
    static symbolicNames = [ null, "STRING", "REFERENCE", "INTEGER", "FLOAT", 
                             "BOOLEAN", "DATETIME", "DOC", "MAP", "FUNNEL", 
                             "INVERT", "RELATION", "FLOW", "GIVE", "ARROW", 
                             "LC", "RC", "LS", "RS", "COMMA", "DOT", "COLON", 
                             "STAR", "QUANTIFIER", "NAME", "WS" ];
    static ruleNames = [ "struct", "def", "node", "gate", "relation", "give", 
                         "flow", "connections", "connection", "dict", "keyValuePairs", 
                         "attribute", "attRef", "array", "type", "flat" ];

    constructor(input) {
        super(input);
        this._interp = new antlr4.atn.ParserATNSimulator(this, atn, decisionsToDFA, sharedContextCache);
        this.ruleNames = StructureParser.ruleNames;
        this.literalNames = StructureParser.literalNames;
        this.symbolicNames = StructureParser.symbolicNames;
    }



	struct() {
	    let localctx = new StructContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 0, StructureParser.RULE_struct);
	    var _la = 0;
	    try {
	        this.enterOuterAlt(localctx, 1);
	        this.state = 35;
	        this._errHandler.sync(this);
	        _la = this._input.LA(1);
	        while((((_la) & ~0x1f) === 0 && ((1 << _la) & 16256) !== 0)) {
	            this.state = 32;
	            this.def();
	            this.state = 37;
	            this._errHandler.sync(this);
	            _la = this._input.LA(1);
	        }
	        this.state = 38;
	        this.match(StructureParser.EOF);
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	def() {
	    let localctx = new DefContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 2, StructureParser.RULE_def);
	    try {
	        this.enterOuterAlt(localctx, 1);
	        this.state = 45;
	        this._errHandler.sync(this);
	        switch(this._input.LA(1)) {
	        case 7:
	        case 8:
	            this.state = 40;
	            this.node();
	            break;
	        case 9:
	        case 10:
	            this.state = 41;
	            this.gate();
	            break;
	        case 11:
	            this.state = 42;
	            this.relation();
	            break;
	        case 12:
	            this.state = 43;
	            this.flow();
	            break;
	        case 13:
	            this.state = 44;
	            this.give();
	            break;
	        default:
	            throw new antlr4.error.NoViableAltException(this);
	        }
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	node() {
	    let localctx = new NodeContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 4, StructureParser.RULE_node);
	    var _la = 0;
	    try {
	        this.enterOuterAlt(localctx, 1);
	        this.state = 47;
	        _la = this._input.LA(1);
	        if(!(_la===7 || _la===8)) {
	        this._errHandler.recoverInline(this);
	        }
	        else {
	        	this._errHandler.reportMatch(this);
	            this.consume();
	        }
	        this.state = 48;
	        this.match(StructureParser.NAME);
	        this.state = 49;
	        this.dict();
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	gate() {
	    let localctx = new GateContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 6, StructureParser.RULE_gate);
	    var _la = 0;
	    try {
	        this.enterOuterAlt(localctx, 1);
	        this.state = 51;
	        _la = this._input.LA(1);
	        if(!(_la===9 || _la===10)) {
	        this._errHandler.recoverInline(this);
	        }
	        else {
	        	this._errHandler.reportMatch(this);
	            this.consume();
	        }
	        this.state = 52;
	        this.match(StructureParser.NAME);
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	relation() {
	    let localctx = new RelationContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 8, StructureParser.RULE_relation);
	    try {
	        this.enterOuterAlt(localctx, 1);
	        this.state = 54;
	        this.match(StructureParser.RELATION);
	        this.state = 55;
	        this.match(StructureParser.NAME);
	        this.state = 56;
	        this.match(StructureParser.NAME);
	        this.state = 57;
	        this.match(StructureParser.ARROW);
	        this.state = 58;
	        this.match(StructureParser.QUANTIFIER);
	        this.state = 59;
	        this.match(StructureParser.NAME);
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	give() {
	    let localctx = new GiveContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 10, StructureParser.RULE_give);
	    try {
	        this.enterOuterAlt(localctx, 1);
	        this.state = 61;
	        this.match(StructureParser.GIVE);
	        this.state = 62;
	        this.match(StructureParser.NAME);
	        this.state = 63;
	        this.match(StructureParser.ARROW);
	        this.state = 64;
	        this.match(StructureParser.NAME);
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	flow() {
	    let localctx = new FlowContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 12, StructureParser.RULE_flow);
	    try {
	        this.enterOuterAlt(localctx, 1);
	        this.state = 66;
	        this.match(StructureParser.FLOW);
	        this.state = 67;
	        this.match(StructureParser.NAME);
	        this.state = 68;
	        this.match(StructureParser.NAME);
	        this.state = 69;
	        this.match(StructureParser.ARROW);
	        this.state = 70;
	        this.match(StructureParser.NAME);
	        this.state = 71;
	        this.connections();
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	connections() {
	    let localctx = new ConnectionsContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 14, StructureParser.RULE_connections);
	    var _la = 0;
	    try {
	        this.enterOuterAlt(localctx, 1);
	        this.state = 73;
	        this.match(StructureParser.LC);
	        this.state = 83;
	        this._errHandler.sync(this);
	        switch (this._input.LA(1)) {
	        case 22:
	        	this.state = 74;
	        	this.match(StructureParser.STAR);
	        	break;
	        case 24:
	        	this.state = 75;
	        	this.connection();
	        	this.state = 80;
	        	this._errHandler.sync(this);
	        	_la = this._input.LA(1);
	        	while(_la===19) {
	        	    this.state = 76;
	        	    this.match(StructureParser.COMMA);
	        	    this.state = 77;
	        	    this.connection();
	        	    this.state = 82;
	        	    this._errHandler.sync(this);
	        	    _la = this._input.LA(1);
	        	}
	        	break;
	        case 16:
	        	break;
	        default:
	        	break;
	        }
	        this.state = 85;
	        this.match(StructureParser.RC);
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	connection() {
	    let localctx = new ConnectionContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 16, StructureParser.RULE_connection);
	    try {
	        this.enterOuterAlt(localctx, 1);
	        this.state = 87;
	        this.attRef();
	        this.state = 88;
	        this.match(StructureParser.ARROW);
	        this.state = 89;
	        this.attRef();
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	dict() {
	    let localctx = new DictContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 18, StructureParser.RULE_dict);
	    var _la = 0;
	    try {
	        this.enterOuterAlt(localctx, 1);
	        this.state = 91;
	        this.match(StructureParser.LC);
	        this.state = 93;
	        this._errHandler.sync(this);
	        _la = this._input.LA(1);
	        if(_la===24) {
	            this.state = 92;
	            this.keyValuePairs();
	        }

	        this.state = 95;
	        this.match(StructureParser.RC);
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	keyValuePairs() {
	    let localctx = new KeyValuePairsContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 20, StructureParser.RULE_keyValuePairs);
	    var _la = 0;
	    try {
	        this.enterOuterAlt(localctx, 1);
	        this.state = 97;
	        this.attribute();
	        this.state = 102;
	        this._errHandler.sync(this);
	        _la = this._input.LA(1);
	        while(_la===19) {
	            this.state = 98;
	            this.match(StructureParser.COMMA);
	            this.state = 99;
	            this.attribute();
	            this.state = 104;
	            this._errHandler.sync(this);
	            _la = this._input.LA(1);
	        }
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	attribute() {
	    let localctx = new AttributeContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 22, StructureParser.RULE_attribute);
	    try {
	        this.enterOuterAlt(localctx, 1);
	        this.state = 105;
	        this.match(StructureParser.NAME);
	        this.state = 106;
	        this.match(StructureParser.COLON);
	        this.state = 107;
	        this.type();
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	attRef() {
	    let localctx = new AttRefContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 24, StructureParser.RULE_attRef);
	    var _la = 0;
	    try {
	        this.enterOuterAlt(localctx, 1);
	        this.state = 109;
	        this.match(StructureParser.NAME);
	        this.state = 114;
	        this._errHandler.sync(this);
	        _la = this._input.LA(1);
	        while(_la===20) {
	            this.state = 110;
	            this.match(StructureParser.DOT);
	            this.state = 111;
	            this.match(StructureParser.NAME);
	            this.state = 116;
	            this._errHandler.sync(this);
	            _la = this._input.LA(1);
	        }
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	array() {
	    let localctx = new ArrayContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 26, StructureParser.RULE_array);
	    try {
	        this.enterOuterAlt(localctx, 1);
	        this.state = 117;
	        this.match(StructureParser.LS);
	        this.state = 118;
	        this.type();
	        this.state = 119;
	        this.match(StructureParser.RS);
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	type() {
	    let localctx = new TypeContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 28, StructureParser.RULE_type);
	    try {
	        this.state = 124;
	        this._errHandler.sync(this);
	        switch(this._input.LA(1)) {
	        case 1:
	        case 2:
	        case 3:
	        case 4:
	        case 5:
	        case 6:
	            this.enterOuterAlt(localctx, 1);
	            this.state = 121;
	            this.flat();
	            break;
	        case 17:
	            this.enterOuterAlt(localctx, 2);
	            this.state = 122;
	            this.array();
	            break;
	        case 15:
	            this.enterOuterAlt(localctx, 3);
	            this.state = 123;
	            this.dict();
	            break;
	        default:
	            throw new antlr4.error.NoViableAltException(this);
	        }
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}



	flat() {
	    let localctx = new FlatContext(this, this._ctx, this.state);
	    this.enterRule(localctx, 30, StructureParser.RULE_flat);
	    var _la = 0;
	    try {
	        this.enterOuterAlt(localctx, 1);
	        this.state = 126;
	        _la = this._input.LA(1);
	        if(!((((_la) & ~0x1f) === 0 && ((1 << _la) & 126) !== 0))) {
	        this._errHandler.recoverInline(this);
	        }
	        else {
	        	this._errHandler.reportMatch(this);
	            this.consume();
	        }
	    } catch (re) {
	    	if(re instanceof antlr4.error.RecognitionException) {
		        localctx.exception = re;
		        this._errHandler.reportError(this, re);
		        this._errHandler.recover(this, re);
		    } else {
		    	throw re;
		    }
	    } finally {
	        this.exitRule();
	    }
	    return localctx;
	}


}

StructureParser.EOF = antlr4.Token.EOF;
StructureParser.STRING = 1;
StructureParser.REFERENCE = 2;
StructureParser.INTEGER = 3;
StructureParser.FLOAT = 4;
StructureParser.BOOLEAN = 5;
StructureParser.DATETIME = 6;
StructureParser.DOC = 7;
StructureParser.MAP = 8;
StructureParser.FUNNEL = 9;
StructureParser.INVERT = 10;
StructureParser.RELATION = 11;
StructureParser.FLOW = 12;
StructureParser.GIVE = 13;
StructureParser.ARROW = 14;
StructureParser.LC = 15;
StructureParser.RC = 16;
StructureParser.LS = 17;
StructureParser.RS = 18;
StructureParser.COMMA = 19;
StructureParser.DOT = 20;
StructureParser.COLON = 21;
StructureParser.STAR = 22;
StructureParser.QUANTIFIER = 23;
StructureParser.NAME = 24;
StructureParser.WS = 25;

StructureParser.RULE_struct = 0;
StructureParser.RULE_def = 1;
StructureParser.RULE_node = 2;
StructureParser.RULE_gate = 3;
StructureParser.RULE_relation = 4;
StructureParser.RULE_give = 5;
StructureParser.RULE_flow = 6;
StructureParser.RULE_connections = 7;
StructureParser.RULE_connection = 8;
StructureParser.RULE_dict = 9;
StructureParser.RULE_keyValuePairs = 10;
StructureParser.RULE_attribute = 11;
StructureParser.RULE_attRef = 12;
StructureParser.RULE_array = 13;
StructureParser.RULE_type = 14;
StructureParser.RULE_flat = 15;

class StructContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = StructureParser.RULE_struct;
    }

	EOF() {
	    return this.getToken(StructureParser.EOF, 0);
	};

	def = function(i) {
	    if(i===undefined) {
	        i = null;
	    }
	    if(i===null) {
	        return this.getTypedRuleContexts(DefContext);
	    } else {
	        return this.getTypedRuleContext(DefContext,i);
	    }
	};

	enterRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.enterStruct(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.exitStruct(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof StructureVisitor ) {
	        return visitor.visitStruct(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class DefContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = StructureParser.RULE_def;
    }

	node() {
	    return this.getTypedRuleContext(NodeContext,0);
	};

	gate() {
	    return this.getTypedRuleContext(GateContext,0);
	};

	relation() {
	    return this.getTypedRuleContext(RelationContext,0);
	};

	flow() {
	    return this.getTypedRuleContext(FlowContext,0);
	};

	give() {
	    return this.getTypedRuleContext(GiveContext,0);
	};

	enterRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.enterDef(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.exitDef(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof StructureVisitor ) {
	        return visitor.visitDef(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class NodeContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = StructureParser.RULE_node;
    }

	NAME() {
	    return this.getToken(StructureParser.NAME, 0);
	};

	dict() {
	    return this.getTypedRuleContext(DictContext,0);
	};

	DOC() {
	    return this.getToken(StructureParser.DOC, 0);
	};

	MAP() {
	    return this.getToken(StructureParser.MAP, 0);
	};

	enterRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.enterNode(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.exitNode(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof StructureVisitor ) {
	        return visitor.visitNode(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class GateContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = StructureParser.RULE_gate;
    }

	NAME() {
	    return this.getToken(StructureParser.NAME, 0);
	};

	FUNNEL() {
	    return this.getToken(StructureParser.FUNNEL, 0);
	};

	INVERT() {
	    return this.getToken(StructureParser.INVERT, 0);
	};

	enterRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.enterGate(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.exitGate(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof StructureVisitor ) {
	        return visitor.visitGate(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class RelationContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = StructureParser.RULE_relation;
    }

	RELATION() {
	    return this.getToken(StructureParser.RELATION, 0);
	};

	NAME = function(i) {
		if(i===undefined) {
			i = null;
		}
	    if(i===null) {
	        return this.getTokens(StructureParser.NAME);
	    } else {
	        return this.getToken(StructureParser.NAME, i);
	    }
	};


	ARROW() {
	    return this.getToken(StructureParser.ARROW, 0);
	};

	QUANTIFIER() {
	    return this.getToken(StructureParser.QUANTIFIER, 0);
	};

	enterRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.enterRelation(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.exitRelation(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof StructureVisitor ) {
	        return visitor.visitRelation(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class GiveContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = StructureParser.RULE_give;
    }

	GIVE() {
	    return this.getToken(StructureParser.GIVE, 0);
	};

	NAME = function(i) {
		if(i===undefined) {
			i = null;
		}
	    if(i===null) {
	        return this.getTokens(StructureParser.NAME);
	    } else {
	        return this.getToken(StructureParser.NAME, i);
	    }
	};


	ARROW() {
	    return this.getToken(StructureParser.ARROW, 0);
	};

	enterRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.enterGive(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.exitGive(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof StructureVisitor ) {
	        return visitor.visitGive(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class FlowContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = StructureParser.RULE_flow;
    }

	FLOW() {
	    return this.getToken(StructureParser.FLOW, 0);
	};

	NAME = function(i) {
		if(i===undefined) {
			i = null;
		}
	    if(i===null) {
	        return this.getTokens(StructureParser.NAME);
	    } else {
	        return this.getToken(StructureParser.NAME, i);
	    }
	};


	ARROW() {
	    return this.getToken(StructureParser.ARROW, 0);
	};

	connections() {
	    return this.getTypedRuleContext(ConnectionsContext,0);
	};

	enterRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.enterFlow(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.exitFlow(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof StructureVisitor ) {
	        return visitor.visitFlow(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class ConnectionsContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = StructureParser.RULE_connections;
    }

	LC() {
	    return this.getToken(StructureParser.LC, 0);
	};

	RC() {
	    return this.getToken(StructureParser.RC, 0);
	};

	STAR() {
	    return this.getToken(StructureParser.STAR, 0);
	};

	connection = function(i) {
	    if(i===undefined) {
	        i = null;
	    }
	    if(i===null) {
	        return this.getTypedRuleContexts(ConnectionContext);
	    } else {
	        return this.getTypedRuleContext(ConnectionContext,i);
	    }
	};

	COMMA = function(i) {
		if(i===undefined) {
			i = null;
		}
	    if(i===null) {
	        return this.getTokens(StructureParser.COMMA);
	    } else {
	        return this.getToken(StructureParser.COMMA, i);
	    }
	};


	enterRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.enterConnections(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.exitConnections(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof StructureVisitor ) {
	        return visitor.visitConnections(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class ConnectionContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = StructureParser.RULE_connection;
    }

	attRef = function(i) {
	    if(i===undefined) {
	        i = null;
	    }
	    if(i===null) {
	        return this.getTypedRuleContexts(AttRefContext);
	    } else {
	        return this.getTypedRuleContext(AttRefContext,i);
	    }
	};

	ARROW() {
	    return this.getToken(StructureParser.ARROW, 0);
	};

	enterRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.enterConnection(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.exitConnection(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof StructureVisitor ) {
	        return visitor.visitConnection(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class DictContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = StructureParser.RULE_dict;
    }

	LC() {
	    return this.getToken(StructureParser.LC, 0);
	};

	RC() {
	    return this.getToken(StructureParser.RC, 0);
	};

	keyValuePairs() {
	    return this.getTypedRuleContext(KeyValuePairsContext,0);
	};

	enterRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.enterDict(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.exitDict(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof StructureVisitor ) {
	        return visitor.visitDict(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class KeyValuePairsContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = StructureParser.RULE_keyValuePairs;
    }

	attribute = function(i) {
	    if(i===undefined) {
	        i = null;
	    }
	    if(i===null) {
	        return this.getTypedRuleContexts(AttributeContext);
	    } else {
	        return this.getTypedRuleContext(AttributeContext,i);
	    }
	};

	COMMA = function(i) {
		if(i===undefined) {
			i = null;
		}
	    if(i===null) {
	        return this.getTokens(StructureParser.COMMA);
	    } else {
	        return this.getToken(StructureParser.COMMA, i);
	    }
	};


	enterRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.enterKeyValuePairs(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.exitKeyValuePairs(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof StructureVisitor ) {
	        return visitor.visitKeyValuePairs(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class AttributeContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = StructureParser.RULE_attribute;
    }

	NAME() {
	    return this.getToken(StructureParser.NAME, 0);
	};

	COLON() {
	    return this.getToken(StructureParser.COLON, 0);
	};

	type() {
	    return this.getTypedRuleContext(TypeContext,0);
	};

	enterRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.enterAttribute(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.exitAttribute(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof StructureVisitor ) {
	        return visitor.visitAttribute(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class AttRefContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = StructureParser.RULE_attRef;
    }

	NAME = function(i) {
		if(i===undefined) {
			i = null;
		}
	    if(i===null) {
	        return this.getTokens(StructureParser.NAME);
	    } else {
	        return this.getToken(StructureParser.NAME, i);
	    }
	};


	DOT = function(i) {
		if(i===undefined) {
			i = null;
		}
	    if(i===null) {
	        return this.getTokens(StructureParser.DOT);
	    } else {
	        return this.getToken(StructureParser.DOT, i);
	    }
	};


	enterRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.enterAttRef(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.exitAttRef(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof StructureVisitor ) {
	        return visitor.visitAttRef(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class ArrayContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = StructureParser.RULE_array;
    }

	LS() {
	    return this.getToken(StructureParser.LS, 0);
	};

	type() {
	    return this.getTypedRuleContext(TypeContext,0);
	};

	RS() {
	    return this.getToken(StructureParser.RS, 0);
	};

	enterRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.enterArray(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.exitArray(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof StructureVisitor ) {
	        return visitor.visitArray(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class TypeContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = StructureParser.RULE_type;
    }

	flat() {
	    return this.getTypedRuleContext(FlatContext,0);
	};

	array() {
	    return this.getTypedRuleContext(ArrayContext,0);
	};

	dict() {
	    return this.getTypedRuleContext(DictContext,0);
	};

	enterRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.enterType(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.exitType(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof StructureVisitor ) {
	        return visitor.visitType(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}



class FlatContext extends antlr4.ParserRuleContext {

    constructor(parser, parent, invokingState) {
        if(parent===undefined) {
            parent = null;
        }
        if(invokingState===undefined || invokingState===null) {
            invokingState = -1;
        }
        super(parent, invokingState);
        this.parser = parser;
        this.ruleIndex = StructureParser.RULE_flat;
    }

	STRING() {
	    return this.getToken(StructureParser.STRING, 0);
	};

	REFERENCE() {
	    return this.getToken(StructureParser.REFERENCE, 0);
	};

	INTEGER() {
	    return this.getToken(StructureParser.INTEGER, 0);
	};

	FLOAT() {
	    return this.getToken(StructureParser.FLOAT, 0);
	};

	BOOLEAN() {
	    return this.getToken(StructureParser.BOOLEAN, 0);
	};

	DATETIME() {
	    return this.getToken(StructureParser.DATETIME, 0);
	};

	enterRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.enterFlat(this);
		}
	}

	exitRule(listener) {
	    if(listener instanceof StructureListener ) {
	        listener.exitFlat(this);
		}
	}

	accept(visitor) {
	    if ( visitor instanceof StructureVisitor ) {
	        return visitor.visitFlat(this);
	    } else {
	        return visitor.visitChildren(this);
	    }
	}


}




StructureParser.StructContext = StructContext; 
StructureParser.DefContext = DefContext; 
StructureParser.NodeContext = NodeContext; 
StructureParser.GateContext = GateContext; 
StructureParser.RelationContext = RelationContext; 
StructureParser.GiveContext = GiveContext; 
StructureParser.FlowContext = FlowContext; 
StructureParser.ConnectionsContext = ConnectionsContext; 
StructureParser.ConnectionContext = ConnectionContext; 
StructureParser.DictContext = DictContext; 
StructureParser.KeyValuePairsContext = KeyValuePairsContext; 
StructureParser.AttributeContext = AttributeContext; 
StructureParser.AttRefContext = AttRefContext; 
StructureParser.ArrayContext = ArrayContext; 
StructureParser.TypeContext = TypeContext; 
StructureParser.FlatContext = FlatContext; 

import '../styles/App.css';
import React, { useState } from "react";
import ParserHelper from "../parsing/ParserHelper"
import Visualization from '../visualization/Visualization';
import { Structure } from '../parsing/GraphObjects';

function StructureInput(params){
  const [file, setFile] = useState(null); 

  function onChange(e){
    const f = e.target.files[0];
    setFile(f);
    params.handler(params.identifier, f);
  }

  return <div className={"input-wrapper" + (file ? " has-file" : "")}>
      <label htmlFor={params.identifier}>{params.title}</label>
      <input id={params.identifier} type="file" onChange={onChange} style={{visibility: "hidden"}} />
  </div>
}

function App() {
  const [files, setFiles] = useState({});
  const [structures, setStructures] = useState([])

  function getFile(identifier, file){
    setFiles(files => {
      const newFiles = {...files};
      newFiles[identifier] = file;
      return newFiles;
    })
  }

  function generate(){
    for(let key in files) {
      const f = files[key];
      const fileReader = new FileReader();

      fileReader.addEventListener("load", () => {
        const structure = ParserHelper.parseStringToStructure(fileReader.result);
        structure.name = key;
        console.log(key + ":", structure);
        setStructures(structures => [...structures, structure])
      })
      
      fileReader.readAsText(f);
    }
  }

  return (
    <div className="front-page-wrapper">
      <StructureInput title="Choose Prestructure File"  identifier="prestruct"  handler={getFile}/>
      <StructureInput title="Choose Poststructure File" identifier="poststruct" handler={getFile}/>
      <StructureInput title="Choose Restructure File"   identifier="restruct"   handler={getFile}/>
      <button className="generate-button" onClick={generate}>Generate</button>
      {
        structures.map(struct => {
          let dist = 50;
          let nodes = struct.getAllOfGroup("vertex").map(v => v.getVisualizationData());
          let relations = struct.getAllOfType("relation").map(r => r.getVisualizationData())
          return <div key={struct.name}>
            <Visualization 
              size={Math.max(nodes.length * dist, 200)} 
              data={{ nodes, links: relations }}
              style={{ prefDistance: 2*dist, gridGap: dist }}
            />
          </div>
        })
      }
    </div>
  );
}

export default App;

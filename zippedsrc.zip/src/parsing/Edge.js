import { GraphObject } from "./GraphObjects";

class Edge extends GraphObject {
    constructor(type, name, source, target){
        super("edge", type, name);
        this.source = source;
        this.target = target;
        this.endpointsAssigned = false;
    }

    assignEndPoints(sourceStruct, targetStruct) {
        if(this.endpointsAssigned) return;

        this.source = sourceStruct.getObjectByName(this.source);
        this.target = targetStruct.getObjectByName(this.target);

        this.endpointsAssigned = true;
    }

    getVisualizationData(){
        if(this.endpointsAssigned) return ({
            source: this.source.name,
            target: this.target.name
        })
        else return ({
            source: this.source,
            target: this.target
        })
    }

    static equal(e1, e2){
        return e1.name === e2.name && e1.type === e2.type;
    }

    static intersection(l1, l2){
        let result = [];
        for(let e1 of l1) 
            for(let e2 of l2) 
                if(this.equal(e1,e2)) 
                    result.push(e1);
        return result;
    }
}

class Relation extends Edge {
    constructor(type, name, quantity, source, target){
        super(type, name, source, target);
        this.quantity = quantity;
    }

    checkEndPointTypes(){
        let valid = ["doc", "map"];
        if(!valid.includes(this.source.type)) return this.source.type;
        if(!valid.includes(this.target.type)) return this.target.type;
    }
}

class Flow extends Edge {
    constructor(type, name, source, target){
        super(type, name, source, target);
        this.connections = [];
    }

    checkEndPointTypes(){
        let valid = ["doc", "map"];
        if(!valid.includes(this.source.type)) return this.source.type;
        if(!valid.includes(this.target.type)) return this.target.type;
    }
}

class Give extends Edge {
    constructor(type, source, target){
        super(type, "give", source, target);
    }

    checkEndPointTypes(){
        let valid = ["relation", "funnel", "invert"];
        if(!valid.includes(this.source.type)) return this.source.type;
        if(!valid.includes(this.target.type)) return this.target.type;
    }
}

export { Relation, Flow, Give, Edge }
import StructureLexer from "../generated/StructureLexer.js";
import StructureParser from "../generated/StructureParser.js";
import StructureVisitor from "../generated/StructureVisitor.js";

const antlr4 = require('antlr4');

export default class ParserHelper {
    static parseStringToStructure(inputString){

        const chars = new antlr4.InputStream(inputString);
        const lexer = new StructureLexer(chars);
        lexer.strictMode = false;

        const tokenStream = new antlr4.CommonTokenStream(lexer);
        const parser = new StructureParser(tokenStream);
        parser.buildParseTrees = true;
        const tree = parser.struct();

        const visitor = new StructureVisitor();
        return visitor.visitStruct(tree);
    }
}
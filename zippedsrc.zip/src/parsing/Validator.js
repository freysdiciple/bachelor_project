import { Edge } from "./Edge";
import { Attribute, Connection } from "./Attribute";

class Validator {
    validateStructure(structure){

        //Get elements
        let nodes = structure.getAllOfGroup("vertex");
        let relations = structure.getAllOfType("relation");
        let flows = structure.getAllOfType("flow");
        let gates = structure.getAllOfGroup("gate");

        //All names must be unique
        let allNames = structure.elements.map(e => e.name);
        let dict = {};
        for(let name of allNames) 
            if(dict[name]) throw new Error(structure.name + ": Duplicate name: ", name);
            else dict[name] = true;
        
        //Both relation-based and flow-based graphs must be acyclic 
        if(!(this.isAcyclic(nodes, Array.from(relations))))
            throw new Error(structure.name + ": Node-Relation graph must be acyclic");
        if(!(this.isAcyclic(nodes, Array.from(flows))))
            throw new Error(structure.name + ": Node-Flow graph must be acyclic");
        
        //All gates must have at least one input and exactly one output
        for(let gate of gates){
            if(!(gate.incoming.length > 0)) 
                throw new Error(structure.name + ": Gate " + gate.name + " must have incoming gives")
            if(!(gate.outgoing.length === 1))
                throw new Error(structure.name + ": Gate " + gate.name + " must only have one outgoing give");
        }

        //All flows must contain valid attribute connections
        for(let flow of flows) {
            let source = flow.source;
            let target = flow.source;

            for(let connection of flow.connections){
                let sourceAttribute = source.getAttributeFromPath(connection.sourcePath);
                let targetAttribute = target.getAttributeFromPath(connection.targetPath);

                if(!Connection.canFlow(sourceAttribute, targetAttribute)) 
                    throw new Error("Data cannot flow from " + sourceAttribute.type + " to " + targetAttribute.type);
            }
        }
    }

    isAcyclic(nodes = [], links = []){
        let q = nodes.filter(n => Edge.intersection(n.incoming, links).length == 0);

        while(q.length > 0){
            let n = q.shift();

            for(let link of Edge.intersection(n.outgoing, links)){
                let m = link.target;
                links = links.filter(l => !(Edge.equal(l, link)));

                if(Edge.intersection(m.incoming, links).length == 0) q.push(m);
            }
        }

        if(links.length == 0) return true;
        else return false;
    }

    validateRestructure(structure){

    }

    
}
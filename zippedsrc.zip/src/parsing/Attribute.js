
class Attribute {
    constructor(type, name){
        this.type = type;
        this.name = name;
    }

    isDict(){
        return !(typeof this.type === 'string' || this.type instanceof String);
    }
}

class Type {
    constructor(group, type, value){
        this.group = group;
        this.type = type;
        this.value = value;
    }
}

class FlatType extends Type { 
    constructor(type){
        super("flat", type, null);
    }
}

class ArrayType extends Type {
    constructor(value){
        super("array", "array", value);
    }
}

class DictType extends Type {
    constructor(value){
        super("dict", "dict", value);
    }
}

const allowedFlatConversions = {
    string: [],
    integer: ["string", "float"],
    float: ["string", "integer"],
    boolean: ["string", "integer"],
    datetime: ["string", "integer"],
    reference: ["string"]
}

class Connection {
    constructor(sourcePath, targetPath, isStar){
        this.sourcePath = sourcePath;
        this.targetPath = targetPath;
        this.isStar = isStar;
    }

    static canFlow(sAttr, tAttr){
        switch(sAttr.group){
            case "flat": break;
            case "array": break;
            case "dict": break;
        }

        return true;
    }
}

export { Attribute, Connection, Type, FlatType, ArrayType, DictType }
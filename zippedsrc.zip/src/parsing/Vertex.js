import { GraphObject } from "./GraphObjects";

class Vertex extends GraphObject {
    constructor(type, name){
        super("vertex", type, name);
        this.incoming = [];
        this.outgoing = [];
    }
}

class Node extends Vertex {
    constructor(type, name){
        super(type, name);
        this.attributes = [];
    }

    getVisualizationData(){
        return ({
            id: this.name
        })
    }

    getAttributeFromPath(path){
        let depth = 0;
        let currentAttributes = this.attributes;

        while(depth < path.length){
            let attr = currentAttributes.find(a => a.name === path[depth])
            if(!attr) throw new Error("Couldn't find attribute " + path[depth] + " in " + this.name);
            if(depth === path.length - 1) return attr;
            else {
                if(!attr.isDict()) throw new Error("Couldn't dive deeper in " + this.name);
                else {
                    currentAttributes = attr.type;
                    depth++;
                }
            }
        }

        return null;
    }
}

class Gate extends GraphObject {
    constructor(type, name){
        super("gate", type, name);
        this.incoming = [];
        this.outgoing = [];
    }

    getVisualizationData(){
        return ({
            id: this.name
        })
    }
}



export { Node, Gate, Vertex };
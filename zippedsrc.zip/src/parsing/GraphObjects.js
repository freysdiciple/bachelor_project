
class Structure {
    
    setElements(elements){
        //Assign elements
        this.elements = elements;
        if(!elements[elements.length-1]) this.elements.pop();

        //Connect elements via identifiers
        for(let edge of this.getAllOfGroup("edge")) {
            //Also checks if source/target elements exist
            edge.assignEndPoints(this, this);

            //Check that does point to itself
            if(edge.source === edge.target) throw new Error("Edge " + edge.name + " cannot point to source");

            //Check if source/target elements have valid types
            let invalidEndpointType = edge.checkEndPointTypes();
            if(invalidEndpointType) throw new Error("Endpoint of ", edge.name, " cannot be ", invalidEndpointType);
        }
    }

    getAllOfType(type){
        return this.elements.filter(e => e.type === type);
    }

    getAllOfGroup(group){
        return this.elements.filter(e => e.group === group);
    }

    getObjectByName(name) {
        let object = this.elements.find(e => e.name === name);
        if(!object) throw new Error("Object " + name + " doesn't exist");
        else return object;
    }
}

class GraphObject {
    constructor(group, type, name){
        this.group = group;
        this.type = type;
        this.name = name;
    }
}



export { Structure, GraphObject }